import React from "react";

export default class Redemption extends React.Component{

    render(){
        return (
            <div className="container developing text-center vertical-align">
                <p className="developing-header">Feature in development.</p>
                <image src="../assets/cat.gif" className="cat"/>
            </div>
        );
    }

}