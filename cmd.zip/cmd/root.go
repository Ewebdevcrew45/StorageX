// Copyright (C) 2018 Storj Labs, Inc.
// See LICENSE for copying information.

package cmd

import (
	"context"

	
)

const defaultConfDir = "$HOME/.storageX/cli"

// Config is miniogw.Config configuration
type Config struct {
	miniogw.Config
}

func getStorjObjects(ctx context.Context, cfg Config) (minio.ObjectLayer, error) {
	identity, err := cfg.Load()
	if err != nil {
		return nil, err
	}

	uplink, err := cfg.NewGateway(ctx, identity)
	if err != nil {
		return nil, err
	}

	credentials, err := auth.CreateCredentials(cfg.AccessKey, cfg.SecretKey)
	if err != nil {
		return nil, err
	}

	storjObjects, err := uplink.NewGatewayLayer(credentials)
	if err != nil {
		return nil, err
	}

	return storjObjects, nil
}

// RootCmd represents the base command when called without any subcommands
var RootCmd = &cobra.Command{
	Use:   "storageX",
	Short: "A brief description of your application",
}
