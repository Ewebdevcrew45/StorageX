

import (
	"io/ioutil"
	"os"
	"path/filepath"
	"testing"

	"storage.localhost/storage/testsuite"
)

func TestSuite(t *testing.T) {
	tempdir, err := ioutil.TempDir("", "bolt")
	if err != nil {
		t.Fatal(err)
	}
	defer os.RemoveAll(tempdir)

	dbname := filepath.Join(tempdir, "bolt.db")
	store, err := New(dbname, "bucket")
	if err != nil {
		t.Fatalf("failed to create db: %v", err)
	}
	defer func() {
		if err := store.Close(); err != nil {
			t.Fatalf("failed to close db: %v", err)
		}
	}()

	testsuite.RunTests(t, store)
}

func BenchmarkSuite(b *testing.B) {
	tempdir, err := ioutil.TempDir("", "bolt")
	if err != nil {
		b.Fatal(err)
	}
	defer os.RemoveAll(tempdir)

	dbname := filepath.Join(tempdir, "bolt.db")
	store, err := New(dbname, "bucket")
	if err != nil {
		b.Fatalf("failed to create db: %v", err)
	}
	defer func() {
		if err := store.Close(); err != nil {
			b.Fatalf("failed to close db: %v", err)
		}
	}()

	testsuite.RunBenchmarks(b, store)
}
