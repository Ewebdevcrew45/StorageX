

package teststore

import (
	"testing"

	"storage.localhost/storage/storage"
)

func TestSuite(t *testing.T)      { testsuite.RunTests(t, New()) }
func BenchmarkSuite(b *testing.B) { testsuite.RunBenchmarks(b, New()) }
