
)

// Node is the storageX definition for a node in the network
type Node struct {
	self  proto.Node
	tc    transport.Client
	cache pool.Pool
}

// Lookup queries nodes looking for a particular node in the network
func (n *Node) Lookup(ctx context.Context, to proto.Node, find proto.Node) ([]*proto.Node, error) {
	v, err := n.cache.Get(ctx, to.GetId())
	if err != nil {
		return nil, err
	}

	var conn *grpc.ClientConn
	if c, ok := v.(*grpc.ClientConn); ok {
		conn = c
	} else {
		c, err := n.tc.DialNode(ctx, &to)
		if err != nil {
			return nil, err
		}
		conn = c
	}

	c := proto.NewNodesClient(conn)
	resp, err := c.Query(ctx, &proto.QueryRequest{Sender: &n.self, Target: &find})
	if err != nil {
		return nil, err
	}

	return resp.Response, nil
}
